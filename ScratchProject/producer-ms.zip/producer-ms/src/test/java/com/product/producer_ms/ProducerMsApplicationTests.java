package com.product.producer_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
